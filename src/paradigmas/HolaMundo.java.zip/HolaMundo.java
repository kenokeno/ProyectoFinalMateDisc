/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package paradigmas;

/**
 *
 * @author alfredo
 */
public class HolaMundo {
    public static void main(String args[]){
        System.out.println("Hola Mundo");
    }
}
